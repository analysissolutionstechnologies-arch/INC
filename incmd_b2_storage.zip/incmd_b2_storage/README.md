# INCOMEL Backblaze Storage — Odoo 17

Paquete nuevo: incmd_b2_storage. No es actualización directa de incmd_attachment_b2. No instalar ambos interceptores de almacenamiento juntos. Antes de sustituir el anterior hay que adaptar sus referencias b2://; este paquete utiliza b2v2://. No desinstalar el módulo que permite leer adjuntos remotos existentes.

## Instalación
Instalar requirements.txt con el Python del servidor, copiar incmd_b2_storage al addons_path, actualizar aplicaciones e instalar en QA. En Odoo.sh agregar boto3>=1.34,<2 al requirements.txt de la raíz del repositorio. Ubuntu 22.04/24.04: usar el Python y dependencias requeridos por la versión de Odoo. No hay dependencia de comandos propios de Ubuntu.

## Configuración
Menú Backblaze (administradores): crear repositorio S3 privado, endpoint, región, bucket, Application Key ID y Application Key con permisos de lectura/escritura. Probar conexión. Crear reglas: seleccionar módulo opcional y modelo concreto, MIME separados por coma (admite image/*), extensiones y campos binarios de negocio opcionales. Las reglas son por modelo; para cubrir un módulo crear sus reglas por modelo. Los archivos técnicos y modelos ir.*, web.*, bus.*, base.* están excluidos. Archivos sin registro relacionado permanecen locales. Los campos binarios solo se envían si se enumeran explícitamente. No seleccionar campos de logos/iconos/interfaz.

Las cargas se guardan primero con Odoo y luego se transfieren. Ante fallo permanecen locales con reintento en 15 minutos. Activar la acción planificada Backblaze: sincronización y migración (se entrega desactivada). Habilitar Migración histórica en el repositorio para recorrer históricos en lotes. Ejecutar lote también permite prueba manual. Reiniciar recorrido en reglas para reconsiderar históricos tras cambiar filtros. Tamaño máximo por archivo 50 MB por defecto; los mayores permanecen locales.

## Hash y liberación local
Claves SHA-256 por contenido dentro del prefijo y bucket. Comprueba existencia, reutiliza sin PUT si ya existe, descarga y verifica SHA-256/SHA-1/tamaño. Conserva nombre original en Odoo. La limpieza se ejecuta después del commit en una transacción independiente, bajo bloqueo de tabla y solo si no quedan referencias locales. Local Released indica liberado/no requerido; falso puede significar archivo compartido o limpieza pendiente. Se reintenta en el siguiente lote. Serialización de contenido idéntico dentro de esta base; no coordina distintas bases Odoo que escriban simultáneamente al mismo bucket. No convierte automáticamente objetos remotos con claves aleatorias de versiones previas; esos siguen siendo legibles.

## Integridad y acceso
Se conserva ID, res_model, res_id, res_field, checksum y permisos originales. Historial guarda relación, ruta anterior y destino. Verifica SHA1 local y descarga remota antes de cambiar store_fname. La liberación física local se realiza después del commit; GC nativo sigue disponible como limpieza complementaria. No se borran objetos remotos al eliminar adjuntos: se conservan para evitar pérdida por rollback o referencias compartidas. No incluye purga remota automática. Credenciales solo accesibles a administradores; proteger backups de la BD.

Se usa API S3 con firma SigV4 nueva en cada solicitud; no guarda URLs ni tokens de descarga que expiren. Ante ExpiredToken/InvalidToken/RequestExpired reconstruye cliente y reintenta una vez. Application Keys revocadas requieren actualizar configuración. Los documentos se sirven a través de Odoo y sus permisos, sin enlaces públicos. No hay copia local permanente tras migración ni descarga disponible si Backblaze cae. Las lecturas remotas y verificación usan memoria; limitar tamaño y lote según RAM/carga.

## Validación pendiente en servidor
Validaciones estáticas incluidas; no se ejecutó instalación real en Odoo ni pruebas contra su bucket. Probar en QA: instalación, vistas, conexión, carga/descarga de PDF e imagen, permisos con usuario de tienda, fallo de conexión/carga local, cron/reintento, migración, edición de archivo, copia de registro, documentos compartidos, reportes y archivos técnicos. Realizar respaldo antes de migrar. Nunca desinstalar con adjuntos remotos: primero repatriar o mantener lector.

## Versión 27: documentos de la cotización
En Ventas, abrir una cotización y la pestaña Documentos cargados. La galería incluye adjuntos binarios asociados al pedido y sus vínculos Studio compatibles. Cada tarjeta abre la vista previa; las imágenes se amplían al pulsarlas. Ver / actualizar documentos abre una consulta actualizada con modos galería y lista. Los documentos no se eliminan desde esta galería. Las miniaturas usan el lector existente de Odoo/Backblaze, sin duplicar imágenes en el filestore. Se respetan los permisos del usuario.
Actualizar el módulo incmd_b2_storage y recargar el navegador. Validación estática realizada; pendiente prueba funcional en Odoo.sh.

## Versión 28
La pestaña se incorpora al resolver el formulario, sin registrar una vista heredada de sale.order durante la actualización. Esto evita que la instalación de la galería active la validación del modificador personalizado validar_autorizaion. No modifica campos ni reglas comerciales de otras personalizaciones.

## Versión 29: corrección del parser Kanban
La pestaña Documentos cargados ahora contiene el botón Ver documentos cargados. Abre una ventana de galería/lista específica del pedido, con vistas independientes cargadas mediante el mecanismo normal de Odoo. No se inyectan subcampos de ir.attachment en los metadatos del formulario de sale.order. Cada apertura consulta los adjuntos actuales. Las tarjetas abren la vista previa, y la imagen permite abrir el original ampliado.

## Versión 30
En la vista previa de documentos guardados se oculta la barra binaria original (nombre duplicado, cambiar, descargar y eliminar). Se conserva el nombre dentro de la tarjeta y la vista previa ampliable. El selector nativo se muestra solo para documentos nuevos. Esta modificación es visual; no cambia las reglas de acceso del modelo.

## Versión 31
Visor carrusel compacto de 320 × 180 px dentro de Documentos cargados, sin botón de apertura de galería. Flechas anterior/siguiente, nombre y contador. Pulsar la imagen abre el original ampliado. Otros documentos muestran icono y enlace de apertura. Un icono de actualización consulta las últimas cargas sin salir del pedido. No descarga todos los originales para llenar el carrusel: obtiene metadatos y carga únicamente la miniatura visible. Se conservan los permisos de acceso y el almacenamiento existentes. Validación estática; pendiente prueba funcional en Odoo.sh.

## Versión 32: validación en Proyecto
En las tareas se agrega Documentos para validar con carrusel grande adaptable (hasta 1100 px de ancho, imagen de hasta 600 px de alto). Flechas, nombre, contador y apertura del original. Incluye adjuntos directos, de mensajes visibles del chatter, relaciones personalizadas a ir.attachment y documentos de la cotización vinculada por sale_order_id/sale_line_id cuando esos campos existen. Respeta permisos sin sudo; no copia archivos ni cambia su propietario. El carrusel de Ventas conserva su tamaño pequeño. El módulo no modifica el clip nativo del chatter; los documentos exclusivos de una cotización mantienen esa relación y no pasan a ser adjuntos directos de la tarea.

## Versión 33
Backblaze deja de ser una aplicación del menú principal. El menú existente se mueve bajo Ajustes (base.menu_administration), solo para administradores; se conservan sus identificadores y la configuración de repositorios, transferencias y monitoreo. No cambia el almacenamiento. El asunto del clip del chatter continúa pendiente de diagnóstico.

## Versión 34: clip del chatter de Proyecto
La respuesta de adjuntos del chatter nativo en project.task incluye los documentos visibles vinculados a la tarea y a su pedido, también mediante x_studio_pedido. Se conserva la lista nativa y se agregan IDs faltantes sin duplicados. No se cambia res_model/res_id, no se copian archivos ni se migran adjuntos. El carrusel usa la misma selección. Se mantiene la configuración bajo Ajustes. Esta corrección requiere validar el clip y la apertura de los documentos en Odoo.sh; no recupera relaciones de mensajes previamente eliminadas por otros módulos.
